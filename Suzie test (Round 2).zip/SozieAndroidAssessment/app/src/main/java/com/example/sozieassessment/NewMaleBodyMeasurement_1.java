package com.example.sozieassessment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class NewMaleBodyMeasurement_1 extends Fragment {




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.new_male_body_measurement_1, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        Spinner height_feet = (Spinner) view.findViewById(R.id.heightSpinner1);
        ArrayAdapter<CharSequence> height_feet_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.height_feets, android.R.layout.simple_spinner_item);
        height_feet_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        height_feet.setAdapter(height_feet_adapter);

        Spinner height_inches = (Spinner) view.findViewById(R.id.heightSpinner2);
        ArrayAdapter<CharSequence> height_inches_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.height_inches, android.R.layout.simple_spinner_item);
        height_inches_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        height_inches.setAdapter(height_inches_adapter);

        ImageView height_Info_Button = (ImageView) view.findViewById(R.id.height_info_button);
        height_Info_Button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Male_Height_Information height_Class = new Male_Height_Information();
                height_Class.showHeightInformationWindow(v);
            }
        });



        Spinner waist_inches = (Spinner) view.findViewById(R.id.waistSpinner1);
        ArrayAdapter<CharSequence> waist_inches_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.waist_inches, android.R.layout.simple_spinner_item);
        waist_inches_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        waist_inches.setAdapter(waist_inches_adapter);

        Spinner hips_inches = (Spinner) view.findViewById(R.id.waistSpinner2);
        ArrayAdapter<CharSequence> hips_inches_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.hip_inches, android.R.layout.simple_spinner_item);
        hips_inches_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hips_inches.setAdapter(hips_inches_adapter);

        ImageView waist_Info_Button = (ImageView) view.findViewById(R.id.waist_info_button);
        waist_Info_Button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Male_Waist_Information waist_Class = new Male_Waist_Information();
                waist_Class.showHeightInformationWindow(v);
            }
        });



        Spinner chest_inches = (Spinner) view.findViewById(R.id.chestSpinner1);
        ArrayAdapter<CharSequence> chest_inches_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.chest_inches, android.R.layout.simple_spinner_item);
        chest_inches_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chest_inches.setAdapter(chest_inches_adapter);

        ImageView chest_Info_Button = (ImageView) view.findViewById(R.id.chest_info_button);
        chest_Info_Button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Male_Chest_Information chest_Class = new Male_Chest_Information();
                chest_Class.showHeightInformationWindow(v);
            }
        });


        Spinner dress_sizes = (Spinner) view.findViewById(R.id.dress_Sizes_Spinner1);
        ArrayAdapter<CharSequence> dress_sizes_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.dress_sizes, android.R.layout.simple_spinner_item);
        dress_sizes_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dress_sizes.setAdapter(dress_sizes_adapter);


        Spinner top_sizes = (Spinner) view.findViewById(R.id.top_Sizes_Spinner1);
        ArrayAdapter<CharSequence> top_sizes_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.top_sizes, android.R.layout.simple_spinner_item);
        top_sizes_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        top_sizes.setAdapter(top_sizes_adapter);


        Spinner bottom_sizes = (Spinner) view.findViewById(R.id.bottom_Sizes_Spinner1);
        ArrayAdapter<CharSequence> bottom_sizes_adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.bottom_sizes, android.R.layout.simple_spinner_item);
        bottom_sizes_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bottom_sizes.setAdapter(bottom_sizes_adapter);



        //Now

        view.findViewById(R.id.new_Male_Cm_Button_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(NewMaleBodyMeasurement_1.this)
                        .navigate(R.id.action_New_Male_Measurement_1_to_New_Male_Measurement_2);
            }
        });


        view.findViewById(R.id.new_Male_Skip_Button_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(NewMaleBodyMeasurement_1.this)
                        .navigate(R.id.action_New_Male_Measurement_1_to_First_Fragment);
            }
        });


        view.findViewById(R.id.new_Male_Next_Button_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "Successfully Registered!!!", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(NewMaleBodyMeasurement_1.this)
                        .navigate(R.id.action_New_Male_Measurement_1_to_First_Fragment);
            }
        });

        view.findViewById(R.id.new_Male_Click_Here_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "Successfully Registered!!!", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(NewMaleBodyMeasurement_1.this)
                        .navigate(R.id.action_New_Male_Measurement_1_to_Male_Measurement_Guide);
            }
        });

        view.findViewById(R.id.new_Male_Skip_To_Do_1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(NewMaleBodyMeasurement_1.this)
                        .navigate(R.id.action_New_Male_Measurement_1_to_First_Fragment);
            }
        });



    }
}