package com.example.sozieassessment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


public class MaleMeasuringFragment2 extends Fragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_male_measuring2, container, false);
    }





    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.Male_Measure_Inc_Button_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment2.this)
                        .navigate(R.id.action_Male_Measurement2_to_Male_Measurement_1);
            }
        });


        view.findViewById(R.id.Male_Measure_Skip_Button_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment2.this)
                        .navigate(R.id.action_Male_Measurement_2_to_First_Fragment);
            }
        });


        view.findViewById(R.id.Male_Measure_Next_Button_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "Successfully Registered!!!", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(MaleMeasuringFragment2.this)
                        .navigate(R.id.action_Male_Measurement_2_to_First_Fragment);
            }
        });


        view.findViewById(R.id.Male_Measure_2_Click_Here).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment2.this)
                        .navigate(R.id.action_Male_Measurement_2_to_Male_Measurement_Guide);
            }
        });

        view.findViewById(R.id.Male_Measure_2_SkipToDo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment2.this)
                        .navigate(R.id.action_Male_Measurement_2_to_First_Fragment);
            }
        });


    }

}