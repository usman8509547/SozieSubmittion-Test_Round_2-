package com.example.sozieassessment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;


public class MaleMeasuringFragment1 extends Fragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_male_measuring1, container, false);
    }




    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        view.findViewById(R.id.Male_Measure_Cm_Button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment1.this)
                        .navigate(R.id.action_Male_Measurement_1_to_Male_Measurement_2);
            }
        });


        view.findViewById(R.id.Male_Measure_Skip_Button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment1.this)
                        .navigate(R.id.action_Male_Measurement_1_to_First_Fragment);
            }
        });


        view.findViewById(R.id.Male_Measure_Next_Button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "Successfully Registered!!!", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(MaleMeasuringFragment1.this)
                        .navigate(R.id.action_Male_Measurement_1_to_First_Fragment);
            }
        });

        view.findViewById(R.id.Male_Measure_1_Click_Here).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "Successfully Registered!!!", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(MaleMeasuringFragment1.this)
                        .navigate(R.id.action_Male_Measurement_1_to_Male_Measurement_Guide);
            }
        });

        view.findViewById(R.id.Male_Measure_1_SkipToDo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(MaleMeasuringFragment1.this)
                        .navigate(R.id.action_Male_Measurement_1_to_First_Fragment);
            }
        });

    }



}